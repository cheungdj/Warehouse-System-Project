package ca.uwo.model.item.states;
import ca.uwo.utils.ItemResult;


public class ItemStateFactory {
	
	public ItemState create(int quantity) {
		if(quantity > 10) {
			InStockState inStock = new InStockState();
			return inStock;
		}
		else if(quantity > 0 && quantity <= 10) {
			LowStockState lowStock = new LowStockState();
			return lowStock;
		}
		else {
			OutofStockState outofStock = new OutofStockState();
			return outofStock;
		}
	}

}
