package ca.uwo.model.item.states;

import ca.uwo.model.Item;
import ca.uwo.utils.ItemResult;
import ca.uwo.utils.ResponseCode;

public class LowStockState implements ItemState {

	@Override
	public ItemResult deplete(Item item, int quantity) {
		ItemResult itemResult;
		ItemStateFactory stateFactory = new ItemStateFactory();
		int availableQuantity = item.getAvailableQuantity();
		itemResult = new ItemResult("AVAILABLE, LOW STOCK", ResponseCode.Completed);
		if (availableQuantity >= quantity) {
			availableQuantity -= quantity;
		}
		if (availableQuantity <= 0) {
			itemResult = new ItemResult("OUT OF STOCK", ResponseCode.Not_Completed);
		}
		item.setAvailableQuantity(availableQuantity);
		item.setState(stateFactory.create(availableQuantity));
		return itemResult;
	}

	@Override
	public ItemResult replenish(Item item, int quantity) {
		ItemStateFactory stateFactory = new ItemStateFactory();
		int availableQuantity = item.getAvailableQuantity();
		availableQuantity += quantity;
		item.setAvailableQuantity(availableQuantity);
		ItemResult itemResult = new ItemResult("RESTOCKED", ResponseCode.Completed);
		item.setState(stateFactory.create(availableQuantity));
		item.notifyViewers();
		return itemResult;
	}

}
