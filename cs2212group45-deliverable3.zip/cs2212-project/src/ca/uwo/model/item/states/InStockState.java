package ca.uwo.model.item.states;

import ca.uwo.model.Item;
import ca.uwo.utils.ItemResult;
import ca.uwo.utils.ResponseCode;

public class InStockState implements ItemState {

	@Override
	public ItemResult deplete(Item item, int quantity) {
		ItemResult itemResult;
		ItemStateFactory stateFactory = new ItemStateFactory();
		int availableQuantity = item.getAvailableQuantity();
		itemResult = new ItemResult("AVAILABLE", ResponseCode.Completed);
		if(availableQuantity >= quantity) {
			availableQuantity -= quantity;
		}
		if (availableQuantity <= 10 && availableQuantity > 0) {
			itemResult = new ItemResult("AVAILABLE, LOW STOCK", ResponseCode.Completed);
			item.setState(stateFactory.create(availableQuantity));
			item.setAvailableQuantity(availableQuantity);
			item.notifyViewers();
			return itemResult;
		} else if (availableQuantity <= 0) {
			itemResult = new ItemResult("OUT OF STOCK", ResponseCode.Not_Completed);
			item.setAvailableQuantity(availableQuantity);
			item.notifyViewers();
			return itemResult;
		}
		item.setAvailableQuantity(availableQuantity);
		return itemResult;
	}

	@Override
	public ItemResult replenish(Item item, int quantity) {
		int availableQuantity = item.getAvailableQuantity();
		availableQuantity += quantity;
		item.setAvailableQuantity(availableQuantity);
		ItemResult itemResult = new ItemResult("RESTOCKED", ResponseCode.Completed);
		return itemResult;
	}

}
