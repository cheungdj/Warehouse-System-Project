package ca.uwo.viewer.restock.strategies;

import ca.uwo.pricingStrategies.aggregate.AggregateDefaultPricingStrategy;
import ca.uwo.pricingStrategies.aggregate.AggregatePricingStrategy;
import ca.uwo.pricingStrategies.aggregate.TestAggregatePricingStrategy;

public class RestockStrategyFactory {

	/**
	 * create strategy for the total price calculation.
	 * @param type each type is attached to one strategy.
	 * @return one concrete implementation of {@link AggregatePricingStrategy}.
	 */
	public static RestockStrategy create(String type) {
		switch(type) {
		case "strategy2":
			return new RestockStrategy2();
		default:
			return new RestockStrategy1();
		}
		
	}
	
}