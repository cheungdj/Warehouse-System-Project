package ca.uwo.client;

import ca.uwo.utils.Invoice;

/**
 * @author kkontog, ktsiouni, mgrigori
 * The base class of Client.
 */
public abstract class Client {


}
