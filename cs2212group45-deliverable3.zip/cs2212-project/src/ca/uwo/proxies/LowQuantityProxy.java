package ca.uwo.proxies;

import java.util.Map;

import ca.uwo.client.Buyer;
import ca.uwo.client.Supplier;
import ca.uwo.frontend.Facade;

public class LowQuantityProxy extends Proxy {
	private Proxy nextProxy;
	private static LowQuantityProxy instance = null;
	private LowQuantityProxy() {
		
	}
	
	public static LowQuantityProxy getInstance() {
		if (instance == null)
			instance = new LowQuantityProxy();
		
		return instance;
	}
	
	public void setNext(Proxy nextProxy) {
		this.nextProxy = nextProxy;
	}

	@Override
	public void placeOrder(Map<String, Integer> orderDetails, Buyer buyer) {
		int sum = 0;
		for (float f : orderDetails.values()) {
		    sum += f;
		}
		System.out.println(sum);
		if(sum > 10) {
			nextProxy.placeOrder(orderDetails, buyer);
		}
		else {
			System.out.println("Handeling low quantity order: \n");
			Facade facade = Facade.getInstance();
			facade.placeOrder(orderDetails, buyer);
		}
		
	}

	@Override
	public void restock(Map<String, Integer> restockDetails, Supplier supplier) {
		
	}

}
