package ca.uwo.proxies;

import java.util.Map;

import ca.uwo.client.Buyer;
import ca.uwo.client.Supplier;
import ca.uwo.frontend.Facade;

public class HighQuantityProxy extends Proxy{
	private Proxy nextProxy;
	private static HighQuantityProxy instance = null;
	
	public void setNext(Proxy nextProxy) {
		this.nextProxy = nextProxy;
	}
	
	private HighQuantityProxy(){
		
	}
	public static HighQuantityProxy getInstance() {
		if (instance == null)
			instance = new HighQuantityProxy();
		
		return instance;
	}
	@Override
	public void placeOrder(Map<String, Integer> orderDetails, Buyer buyer) {
		int sum = 0;
		for (float f : orderDetails.values()) {
		    sum += f;

		}
		if(sum > 10) {
			System.out.println("Handleling High Quantity Order: \n");
			Facade facade = Facade.getInstance();
			facade.placeOrder(orderDetails, buyer);
		}
		else {
			nextProxy.placeOrder(orderDetails, buyer);
		}
		
	}

	@Override
	public void restock(Map<String, Integer> restockDetails, Supplier supplier) {
		
	}

}
