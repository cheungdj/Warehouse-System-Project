package ca.uwo.proxies;

import java.util.Map;

import ca.uwo.client.Buyer;
import ca.uwo.client.Supplier;
import ca.uwo.frontend.Facade;

public class SupplierProxy extends Proxy {
	private Proxy nextProxy;
	private static SupplierProxy instance = null;
	
	public void setNext(Proxy nextProxy) {
		this.nextProxy = nextProxy;
	}
	public static SupplierProxy getInstance() {
		if (instance == null)
			instance = new SupplierProxy();
		
		return instance;
	}

	private SupplierProxy() {
		
	}
	
	@Override
	public void placeOrder(Map<String, Integer> orderDetails, Buyer buyer) {
		nextProxy.placeOrder(orderDetails, buyer);	
	}

	@Override
	public void restock(Map<String, Integer> restockDetails, Supplier supplier) {
		System.out.println("Entering Supplier Proxy: \n");
		Facade facade = Facade.getInstance();
		facade.restock(restockDetails, supplier);
	}

}
